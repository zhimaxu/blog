---
name: agnes-ai
description: >
  使用 Agnes AI 生成图像、视频，以及识别图片内容。图像模型 agnes-image-2.1-flash，
  视频模型 agnes-video-v2.0，视觉识别模型 agnes-2.0-flash。
  适用于：(1) 根据描述生成图片 (2) 文生视频、图生视频 (3) 识别/描述图片内容。
  当用户需要生成文章配图、创意设计、营销素材、生成视频、或根据图片提问时使用。
  触发词：生成图片、生成视频、配图、插图、生视频、配图生成、图片识别、看图、分析图片。
---

# Agnes AI

使用 Agnes AI 通过 API 生成图像、视频，以及识别图片内容。

## API Key

脚本已内置默认 API Key。`<API_KEY>` 位置写 `default` 即可自动使用内置 Key：

```bash
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default ...
```

也可以手动指定其他 Key：

```bash
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py sk-custom-key ...
```

## 图像生成

```bash
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default "<prompt>" <size>
```

参数：
- `API_KEY`：`default` 使用内置 Key，或传入自定义 Bearer Token
- `prompt`：英文提示词（必须用引号包裹）
- `size`：可选，默认 1024x768
- 默认模型：`agnes-image-2.1-flash`

脚本输出为图像 URL。

## 视频生成

```bash
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default --video "<prompt>" [options]
```

参数：
- `API_KEY`：`default` 使用内置 Key，或传入自定义 Bearer Token
- `--video "<prompt>"`：英文视频描述（必填）
- `--width N`：视频宽度，默认 1152
- `--height N`：视频高度，默认 768
- `--num_frames N`：帧数，必须 <= 441 且符合 8n+1 格式（如 81, 121, 161, 241, 441）
- `--frame_rate N`：FPS，范围 1-60，默认 24
- `--image <URL|本地路径>`：参考图片（图生视频模式）。支持线上 URL、本地文件路径
- `--negative PROMPT`：负面提示词

示例：
```bash
# 文生视频
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default --video "A cinematic shot of a cat on the beach at sunset"

# 图生视频（线上图片）
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default --video "The woman slowly turns around" --image "https://example.com/image.png"

# 图生视频（本地图片，自动上传临时图床）
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default --video "Make the scene come alive with gentle motion" --image "/path/to/local/image.png"
```

视频生成是异步的，脚本会自动轮询结果（默认每 5 秒轮询，最长等待 600 秒）。

### 本地图片自动上传

图生视频时，如果 `--image` 传入本地文件路径，脚本会自动将图片上传到免费临时图床 (uguu.se)，获取公开 URL 后提交给视频 API。这是因为视频 API 对 data URI 的支持不稳定，通过临时图床中转更可靠。

## 图片识别

```bash
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default --recognize "<prompt>" --image <image_url_or_file>
```

参数：
- `API_KEY`：`default` 使用内置 Key，或传入自定义 Bearer Token
- `--recognize "<prompt>"`：对图片的提问或描述指令
- `--image <url_or_file>`：图片的公开 URL 或本地文件路径

示例：
```bash
python3 <SKILL_DIR>/scripts/agnes_ai_generate.py default --recognize "请描述这张图片中的内容" --image "https://example.com/photo.png"
```

使用模型 `agnes-2.0-flash`，支持多模态视觉理解。

## 编写 Prompt

**图像**：`[Subject] + [Scene / Environment] + [Style] + [Lighting] + [Composition] + [Quality Requirements]`

**视频**：`[Subject] + [Action] + [Scene] + [Camera Movement] + [Lighting] + [Style]`

编写要求：
- 描述要具体、视觉化，避免抽象概念
- 包含风格、光照、构图信息
- 参考 `references/prompt-guide.md` 获取详细指南

## 处理结果

- 成功：返回图像/视频 URL 或识别文本
- 失败：输出错误信息，可根据错误调整 prompt 重试（最多 2 次）

## API 配置

### 图像

| 项目 | 值 |
|------|------|
| Endpoint | https://apihub.agnes-ai.com/v1/images/generations |
| Method | POST |
| Auth | Bearer Token |

### 视频

| 项目 | 值 |
|------|------|
| 创建任务 | POST https://apihub.agnes-ai.com/v1/videos |
| 查询结果 | GET https://apihub.agnes-ai.com/v1/videos/{task_id} |
| Auth | Bearer Token |
| 工作流 | 异步任务制，先创建 task，再通过 task_id 查询结果 |
| 定价 | $0.005/秒 |

### 图片识别

| 项目 | 值 |
|------|------|
| Endpoint | https://apihub.agnes-ai.com/v1/chat/completions |
| Method | POST |
| Auth | Bearer Token |
| 模型 | `agnes-2.0-flash`（支持视觉理解） |
| 内容格式 | `content` 数组，包含 `text` 和 `image_url` 类型 |

## 注意事项

- API Key 已内置，使用 `default` 即可，无需每次手动输入
- 不要在公开内容中暴露 API Key
- Prompt 使用英文效果更佳
- 视频生成可能需要较长时间（几分钟到十几分钟），请耐心等待
- `num_frames` 必须符合 `8n + 1` 格式且 <= 441
- 图生视频 `--image` 支持：线上 URL、本地文件路径（自动上传至临时图床 uguu.se，获取公开 URL）
- 图片识别 `--image` 支持：线上 URL、本地文件路径（自动转为 base64 data URI）