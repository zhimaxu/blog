---
name: Prompt Guide
description: Agnes Image 2.1 Flash prompt writing guide with structures and examples.
---

# Prompt Writing Guide

## Recommended Structure

```
[Subject] + [Scene / Environment] + [Style] + [Lighting] + [Composition] + [Quality Requirements]
```

## Writing Rules

1. **Be visual and specific** — describe what can be seen, not abstract ideas
2. **Include style information** — cinematic realism, watercolor, etc.
3. **Specify lighting** — golden hour, neon, soft diffuse, etc.
4. **Define composition** — wide-angle, close-up, rule of thirds, etc.
5. **State detail level** — ultra-detailed, minimalist, high visual density, etc.

## Examples

### Simple scene
```
A luminous floating city above a misty canyon at sunrise, cinematic realism, wide-angle composition, rich architectural details, soft golden light, high visual density
```

### High information density
```
A futuristic city marketplace filled with flying vehicles, holographic signs, dense crowds, neon lighting, cinematic realism, ultra-detailed, high-information-density composition
```

### Winter landscape
```
Convert the image into a fantasy winter landscape, add snow, warm window lights, and a magical atmosphere, while preserving the original building structure and camera angle.
```

## For High Information Density Images

Clearly describe visual hierarchy:
- Subject (primary)
- Background environment
- Important secondary details
- Style and lighting
- Composition constraints