---
name: API Reference
description: Complete Agnes AI API reference for both image and video models.
---

# Agnes AI API Reference

## Image Generation

### Endpoint

```
POST https://apihub.agnes-ai.com/v1/images/generations
```

### Authentication

```
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
```

### Request Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| model | string | Yes | Model name: `agnes-image-2.1-flash` |
| prompt | string | Yes | Text instruction for image generation |
| size | string | No | Output size, e.g. `1024x768` |
| extra_body | object | No | Extra parameters for advanced workflows |

### Response

Returns JSON with `data` array containing image URLs:

```json
{"data": [{"url": "https://..." }]}
```

### cURL Examples

#### Text-to-Image

```bash
curl https://apihub.agnes-ai.com/v1/images/generations \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-image-2.1-flash",
    "prompt": "A luminous floating city above a misty canyon at sunrise, cinematic realism",
    "size": "1024x768"
  }'
```

---

## Video Generation

### Endpoints

| Description | Endpoint |
|---|---|
| Create Task | `POST https://apihub.agnes-ai.com/v1/videos` |
| Get Result | `GET https://apihub.agnes-ai.com/v1/videos/{task_id}` |

### Authentication

```
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
```

### Create Task — Request Parameters

| Required | Parameter | Type | Description |
|---|---|---|---|
| Yes | `model` | string | Fixed as `agnes-video-v2.0` |
| Yes | `prompt` | string | Text description of the video |
| No | `image` | string | Input image URL (for image-to-video) |
| No | `mode` | string | Generation mode: `ti2vid` or `keyframes` |
| No | `height` | integer | Video height, default 768 |
| No | `width` | integer | Video width, default 1152 |
| No | `num_frames` | integer | Frame count, <= 441 and must follow `8n + 1` (e.g. 81, 121, 161, 241, 441) |
| No | `num_inference_steps` | integer | Number of inference steps |
| No | `seed` | integer | Random seed for reproducible results |
| No | `frame_rate` | number | Video FPS, range 1-60 |
| No | `negative_prompt` | string | What to avoid in the video |
| No | `extra_body.image` | array | Image URLs for multi-image or keyframes mode |
| No | `extra_body.mode` | string | Additional config, e.g. `keyframes` |

### Create Task — Response

```json
{
  "id": "task_123456",
  "object": "video",
  "model": "agnes-video-v2.0",
  "status": "queued",
  "progress": 0,
  "created_at": 1774344160
}
```

### Get Result — Response (completed)

```json
{
  "id": "task_123456",
  "object": "video",
  "model": "agnes-video-v2.0",
  "status": "completed",
  "progress": 100,
  "created_at": 1774344160,
  "completed_at": 1774344311,
  "video_url": "https://storage.googleapis.com/...",
  "remixed_from_video_id": "https://storage.googleapis.com/...",
  "size": "1152x768",
  "seconds": "5.0",
  "usage": { "duration_seconds": 151 }
}
```

注意：API 可能返回 `video_url` 或 `remixed_from_video_id`，两者都是视频结果 URL。

### Task States

| Status | Description |
|---|---|
| `queued` | Waiting in queue |
| `in_progress` | Generating |
| `completed` | Finished, `video_url` available |
| `failed` | Generation failed |

### Error Codes

| Code | Description |
|---|---|
| 400 | Invalid request |
| 401 | Unauthorized, check API Key |
| 404 | Task not found |
| 500 | Server error |
| 503 | Service busy, try later |

### Pricing

| Type | Price |
|---|---|
| Video Duration | $0.005/s |

### cURL Examples

#### Text-to-Video

```bash
curl -X POST https://apihub.agnes-ai.com/v1/videos \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-video-v2.0",
    "prompt": "A cinematic shot of a cat walking on the beach at sunset, soft ocean waves, warm golden lighting",
    "height": 768,
    "width": 1152,
    "num_frames": 121,
    "frame_rate": 24
  }'
```

#### Image-to-Video

```bash
curl -X POST https://apihub.agnes-ai.com/v1/videos \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-video-v2.0",
    "prompt": "The woman slowly turns around and looks back at the camera, cinematic camera movement",
    "image": "https://example.com/image.png",
    "num_frames": 121,
    "frame_rate": 24
  }'
```

#### Multi-Image Video

```bash
curl -X POST https://apihub.agnes-ai.com/v1/videos \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-video-v2.0",
    "prompt": "Create a smooth transformation between the two images, cinematic lighting",
    "extra_body": {
      "image": ["https://example.com/img1.png", "https://example.com/img2.png"]
    },
    "num_frames": 121,
    "frame_rate": 24
  }'
```

#### Keyframe Animation

```bash
curl -X POST https://apihub.agnes-ai.com/v1/videos \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-video-v2.0",
    "prompt": "Smooth cinematic transition between keyframes, visual consistency, natural camera movement",
    "extra_body": {
      "image": ["https://example.com/kf1.png", "https://example.com/kf2.png"],
      "mode": "keyframes"
    },
    "num_frames": 121,
    "frame_rate": 24
  }'
```

#### Get Result

```bash
curl -X GET https://apihub.agnes-ai.com/v1/videos/{task_id} \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Prompt Best Practices

- **Text-to-Video**: `[Subject] + [Action] + [Scene] + [Camera Movement] + [Lighting] + [Style]`
- **Image-to-Video**: Describe what should move while keeping main subject stable
- **Multi-Image**: Describe how input images relate to each other
- **Keyframes**: Clearly describe the transition between keyframes

### Recommended Settings

| Use Case | Settings |
|---|---|
| Standard video | `width: 1152`, `height: 768`, `num_frames: 121`, `frame_rate: 24` |
| Social media short | `num_frames: 81` or `121`, `frame_rate: 24` |
| Smoother motion | Higher `frame_rate` like 24 or 30 |
| Reproducible results | Set fixed `seed` |
| Keyframe transition | `extra_body.mode: "keyframes"` |

### Important Notes

- Video generation is asynchronous — create task first, then poll via `task_id`
- `num_frames` must be <= 441 and follow `8n + 1` format
- `video_url` is only available when status is `completed`
- Expected wait time: several minutes

---

## Image Recognition (Vision)

### Endpoint

```
POST https://apihub.agnes-ai.com/v1/chat/completions
```

### Authentication

```
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
```

### Request Parameters

| Parameter | Type | Required | Description |
|---|---|---|---|
| model | string | Yes | Model name: `agnes-2.0-flash` |
| messages | array | Yes | Message array with user role |
| messages[].role | string | Yes | Always `user` |
| messages[].content | array | Yes | Array of content parts |
| messages[].content[].type | string | Yes | `text` or `image_url` |
| messages[].content[].text | string | Yes | Question or instruction about the image |
| messages[].content[].image_url.url | string | Yes | Public URL of the image |
| messages[].content[].image_url.detail | string | No | `high` or `low`, default `high` |
| max_tokens | integer | No | Max output tokens, default 2048 |

### Response

Returns JSON with `choices` array containing text response:

```json
{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "The image shows..."
      }
    }
  ]
}
```

### cURL Example

```bash
curl -X POST https://apihub.agnes-ai.com/v1/chat/completions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-2.0-flash",
    "messages": [
      {
        "role": "user",
        "content": [
          {"type": "text", "text": "请描述这张图片中的内容"},
          {
            "type": "image_url",
            "image_url": {
              "url": "https://example.com/photo.png",
              "detail": "high"
            }
          }
        ]
      }
    ],
    "max_tokens": 2048
  }'
```

### Important Notes

- Model `agnes-2.0-flash` supports multimodal vision understanding
- Image URL must be publicly accessible
- `detail: "high"` provides more detailed analysis than `"low"`