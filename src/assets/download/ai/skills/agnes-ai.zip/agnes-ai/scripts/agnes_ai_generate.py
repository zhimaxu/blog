#!/usr/bin/env python3
"""Generate images, videos, and recognize images using Agnes AI."""

import sys
import json
import urllib.request
import urllib.error
import time

DEFAULT_API_KEY = "sk-j5isVaGmLs9b4jhecD51YC35ChMW54wKwbdiVJf00Juxqrqf"

def upload_to_temp_host(filepath: str) -> str:
    """Upload a local image to temporary hosting and return the public URL.

    Uses uguu.se — a free, no-API-key file host. Returns a short-lived public URL
    suitable for passing to the video/image API as an image reference.
    """
    import os
    import urllib.parse

    filename = os.path.basename(filepath)
    boundary = "----FormBoundary" + os.urandom(16).hex()
    with open(filepath, "rb") as f:
        file_data = f.read()

    # Multipart form-data body
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="files[]"; filename="{filename}"\r\n'
        f"Content-Type: application/octet-stream\r\n\r\n"
    ).encode("utf-8") + file_data + (
        f"\r\n--{boundary}--\r\n"
    ).encode("utf-8")

    req = urllib.request.Request(
        "https://uguu.se/upload",
        data=body,
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read().decode("utf-8"))

    if result.get("success") and result.get("files"):
        url = result["files"][0]["url"]
        print(f"  Uploaded local image → {url}", file=sys.stderr)
        return url
    raise RuntimeError(f"Upload failed: {json.dumps(result, ensure_ascii=False)[:300]}")


def generate_image(api_key: str, prompt: str, model: str = "agnes-image-2.1-flash", size: str = "1024x768") -> str:
    """Generate a single image from a text prompt. Returns the image URL."""
    url = "https://apihub.agnes-ai.com/v1/images/generations"
    payload = {
        "model": model,
        "prompt": prompt,
        "size": size,
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read().decode("utf-8"))
    # Standard response: data[0].url
    if "data" in result and len(result["data"]) > 0:
        return result["data"][0]["url"]
    raise ValueError(f"Unexpected API response: {json.dumps(result, ensure_ascii=False)[:500]}")


def generate_video(api_key: str, prompt: str, model: str = "agnes-video-v2.0",
                   width: int = 1152, height: int = 768, num_frames: int = 121,
                   frame_rate: int = 24, image: str = None, extra_body: dict = None,
                   negative_prompt: str = None, seed: int = None,
                   num_inference_steps: int = None, mode: str = None) -> str:
    """Generate a video from a text prompt or reference image. Returns the task_id.

    Usage:
        task_id = generate_video(api_key, "A cat walking on the beach")
        video_url = poll_video_result(api_key, task_id)

    Parameters:
        prompt: Textual description of the video
        image: Optional reference image URL (for image-to-video)
        width/height: Video resolution
        num_frames: Must be <= 441 and follow 8n+1 format (e.g. 81, 121, 161, 241, 441)
        frame_rate: FPS, range 1-60
        negative_prompt: What to avoid in the video
        extra_body: Additional config, e.g. {"image": [...], "mode": "keyframes"}
    """
    url = "https://apihub.agnes-ai.com/v1/videos"
    payload = {
        "model": model,
        "prompt": prompt,
        "height": height,
        "width": width,
        "num_frames": num_frames,
        "frame_rate": frame_rate,
    }
    if image:
        # Local file → upload to temp host for reliable public URL
        if not (image.startswith("http://") or image.startswith("https://") or image.startswith("data:")):
            print(f"  Local image detected, uploading to temp host...", file=sys.stderr)
            image = upload_to_temp_host(image)
        payload["image"] = image
    if negative_prompt:
        payload["negative_prompt"] = negative_prompt
    if seed is not None:
        payload["seed"] = seed
    if num_inference_steps is not None:
        payload["num_inference_steps"] = num_inference_steps
    if mode:
        payload["mode"] = mode
    if extra_body:
        payload["extra_body"] = extra_body

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read().decode("utf-8"))

    if "id" in result:
        return result["id"]
    raise ValueError(f"Unexpected API response: {json.dumps(result, ensure_ascii=False)[:500]}")


def poll_video_result(api_key: str, task_id: str, interval: int = 5, max_wait: int = 600) -> str:
    """Poll for video generation result. Returns the video URL.

    Blocks until the video is completed or max_wait is reached.
    """
    url = f"https://apihub.agnes-ai.com/v1/videos/{task_id}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {api_key}",
        },
        method="GET",
    )

    waited = 0
    while waited < max_wait:
        time.sleep(interval)
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        status = result.get("status", "")
        progress = result.get("progress", 0)
        print(f"  Status: {status}, Progress: {progress}%  (waited {waited}s)", file=sys.stderr)

        if status == "completed":
            return result.get("video_url") or result.get("remixed_from_video_id", "")
        elif status == "failed":
            raise RuntimeError(f"Video generation failed: {json.dumps(result, ensure_ascii=False)[:500]}")

        waited += interval

    raise TimeoutError(f"Video generation timed out after {max_wait}s")


def recognize_image(api_key: str, prompt: str, image_source: str, model: str = "agnes-2.0-flash", max_tokens: int = 2048) -> str:
    """Recognize/describe an image using agnes-2.0-flash vision model.

    Parameters:
        api_key: Bearer token
        prompt: Question or instruction about the image
        image_source: Public image URL OR local file path (auto-detected)
        model: Model name, default "agnes-2.0-flash"
        max_tokens: Max output tokens

    Returns: The model's text response.
    """
    url = "https://apihub.agnes-ai.com/v1/chat/completions"

    # Auto-detect: local file or URL
    if image_source.startswith("http://") or image_source.startswith("https://"):
        image_part = {
            "type": "image_url",
            "image_url": {"url": image_source, "detail": "high"},
        }
    else:
        # Local file — read and convert to data URI
        import base64
        try:
            with open(image_source, "rb") as f:
                data = f.read()
        except FileNotFoundError:
            raise FileNotFoundError(f"Local image file not found: {image_source}")
        b64 = base64.b64encode(data).decode("utf-8")
        mime = "image/png"
        if image_source.lower().endswith((".jpg", ".jpeg")):
            mime = "image/jpeg"
        elif image_source.lower().endswith(".webp"):
            mime = "image/webp"
        image_part = {
            "type": "image_url",
            "image_url": {"url": f"data:{mime};base64,{b64}", "detail": "high"},
        }

    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    image_part,
                ],
            }
        ],
        "max_tokens": max_tokens,
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read().decode("utf-8"))

    if "choices" in result and len(result["choices"]) > 0:
        return result["choices"][0]["message"]["content"]
    raise ValueError(f"Unexpected API response: {json.dumps(result, ensure_ascii=False)[:500]}")


def main():
    """
    CLI entry point.

    Usage (text-to-image):
        python agnes_ai_generate.py <api_key> "<prompt>" [size]

    Usage (text-to-video):
        python agnes_ai_generate.py <api_key> --video <prompt> [options]

    Usage (image-recognition):
        python agnes_ai_generate.py <api_key> --recognize <prompt> --image <url>
    """
    if len(sys.argv) < 3:
        print("Usage: agnes_ai_generate.py <api_key> [options]", file=sys.stderr)
        sys.exit(1)

    api_key = sys.argv[1]
    if api_key == "default":
        api_key = DEFAULT_API_KEY

    # Mode dispatch
    mode = None
    if "--recognize" in sys.argv:
        mode = "recognize"
    elif "--video" in sys.argv:
        mode = "video"
    else:
        mode = "image"

    # --- image mode (default) ---
    if mode == "image":
        if len(sys.argv) < 4:
            print("Usage: agnes_ai_generate.py <api_key> <prompt> [size]", file=sys.stderr)
            sys.exit(1)
        prompt = sys.argv[2]
        size = sys.argv[3] if len(sys.argv) > 3 else "1024x768"
        try:
            url = generate_image(api_key, prompt, size=size)
            print(url)
        except Exception as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        return

    # --- video mode ---
    if mode == "video":
        width = 1152
        height = 768
        num_frames = 121
        frame_rate = 24
        image = None
        negative_prompt = None
        prompt = None

        i = 2
        while i < len(sys.argv):
            arg = sys.argv[i]
            if arg == "--video" and i + 1 < len(sys.argv):
                prompt = sys.argv[i + 1]; i += 2
            elif arg == "--width" and i + 1 < len(sys.argv):
                width = int(sys.argv[i + 1]); i += 2
            elif arg == "--height" and i + 1 < len(sys.argv):
                height = int(sys.argv[i + 1]); i += 2
            elif arg == "--num_frames" and i + 1 < len(sys.argv):
                num_frames = int(sys.argv[i + 1]); i += 2
            elif arg == "--frame_rate" and i + 1 < len(sys.argv):
                frame_rate = int(sys.argv[i + 1]); i += 2
            elif arg == "--image" and i + 1 < len(sys.argv):
                image = sys.argv[i + 1]; i += 2
            elif arg == "--negative" and i + 1 < len(sys.argv):
                negative_prompt = sys.argv[i + 1]; i += 2
            else:
                i += 1

        if not prompt:
            print("ERROR: --video <prompt> is required", file=sys.stderr)
            sys.exit(1)

        try:
            print(f"Creating video task...", file=sys.stderr)
            task_id = generate_video(
                api_key, prompt, width=width, height=height,
                num_frames=num_frames, frame_rate=frame_rate,
                image=image, negative_prompt=negative_prompt,
            )
            print(f"Task ID: {task_id}", file=sys.stderr)
            print(f"Polling result... (task_id={task_id})", file=sys.stderr)
            video_url = poll_video_result(api_key, task_id)
            print(video_url)
        except Exception as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        return

    # --- recognize mode ---
    if mode == "recognize":
        prompt = None
        image_source = None

        i = 2
        while i < len(sys.argv):
            arg = sys.argv[i]
            if arg == "--recognize" and i + 1 < len(sys.argv):
                prompt = sys.argv[i + 1]; i += 2
            elif arg == "--image" and i + 1 < len(sys.argv):
                image_source = sys.argv[i + 1]; i += 2
            else:
                i += 1

        if not prompt or not image_source:
            print("Usage: agnes_ai_generate.py <api_key> --recognize <prompt> --image <url_or_file_path>", file=sys.stderr)
            sys.exit(1)

        try:
            result = recognize_image(api_key, prompt, image_source)
            print(result)
        except Exception as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        return

if __name__ == "__main__":
    main()